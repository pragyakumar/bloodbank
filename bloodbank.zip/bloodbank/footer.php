<footer>
	
	<script>
		date = new Date();
    	document.getElementById("demo").innerHTML=date.getFullYear();
    </script>
</footer>