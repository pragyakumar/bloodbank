<?php 
    session_start();

    ?>
<!DOCTYPE html>
<html>
<?php $title="Bloodbank" ?>
<?php require 'head.php'; ?>
<body>
    <?php require 'header.php'; ?>

    <div class="container cont">

   <?php require 'message.php'; ?>

        

        <div class="row mb-5">
            <div class="col-lg-12">
            <div class="card">
                <div class="card-header">Basic Information</div>
                <div class="card-body">
                    <dt>Blood Type A+</dt>
                    <dd>you can give blood to A+ and AB+ and can receive blood from A+, A-, O+ and O-</dd>
					<dt>Blood Type A-</dt>
                    <dd>you can give blood to A+, A-, AB- and AB+ and can receive blood from A- and O-</dd>
					<dt>Blood Type B+</dt>
                    <dd>you can give blood to B+ and AB+ and can receive blood from B+, B-, O+ and O-</dd>
					<dt>Blood Type B-</dt>
                    <dd>you can give blood to B+, B-, AB- and AB+ and can receive blood from B- and O-</dd>
					<dt>Blood Type AB+</dt>
                    <dd>you can give blood to AB+ and can receive blood from Everyone</dd>
					<dt>Blood Type AB-</dt>
                    <dd>you can give blood to AB+ and AB- and can receive blood from A-, B-, AB- and O-</dd>
					<dt>Blood Type O+</dt>
                    <dd>you can give blood to A+, O+, B+ and AB+ and can receive blood from O+ and O-</dd>
					<dt>Blood Type O-</dt>
                    <dd>you can give blood to Everyone and can receive blood from O-</dd>
                    </div>
            </div>
            </div>
        </div>
    </div>

    <?php require 'footer.php'; ?>

</body>
</html>